<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="icon" href="images/favicon.ico">
    <style>
        .hero-section {
            background: url('images/hero-bg.jpg') no-repeat center center;
            background-size: cover;
            padding: 100px 0;
            color: white;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
        }
        .product-card {
            transition: transform 0.3s;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include 'element/nav.php'; ?>
    
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container text-center">
            <h1 class="display-4">Welcome to <?php echo SITE_NAME; ?></h1>
            <p class="lead">Discover amazing products at unbeatable prices</p>
            <a href="products.php" class="btn btn-primary btn-lg">Shop Now</a>
        </div>
    </section>
    
    <!-- Featured Products -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Featured Products</h2>
            <div class="row">
                <?php
                $sql = "SELECT * FROM products WHERE featured=1 LIMIT 4";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-3 mb-4">
                            <div class="card product-card h-100">
                                <img src="product_pic/'.$row['image'].'" class="card-img-top" alt="'.$row['name'].'">
                                <div class="card-body">
                                    <h5 class="card-title">'.$row['name'].'</h5>
                                    <p class="card-text">₹'.$row['price'].'</p>
                                    <a href="product_details.php?id='.$row['id'].'" class="btn btn-primary">View Details</a>
                                </div>
                            </div>
                        </div>';
                    }
                } else {
                    echo '<div class="col-12"><p class="text-center">No featured products found.</p></div>';
                }
                ?>
            </div>
        </div>
    </section>
    
    <!-- Categories -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Shop by Category</h2>
            <div class="row">
                <?php
                $sql = "SELECT * FROM categories LIMIT 4";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-3 mb-4">
                            <div class="card h-100">
                                <img src="category_images/'.$row['image'].'" class="card-img-top" alt="'.$row['name'].'">
                                <div class="card-body text-center">
                                    <h5 class="card-title">'.$row['name'].'</h5>
                                    <a href="category.php?id='.$row['id'].'" class="btn btn-outline-primary">View Products</a>
                                </div>
                            </div>
                        </div>';
                    }
                } else {
                    echo '<div class="col-12"><p class="text-center">No categories found.</p></div>';
                }
                ?>
            </div>
        </div>
    </section>
    
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y').' '.SITE_NAME; ?>. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>