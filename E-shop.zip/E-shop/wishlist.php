<?php 
require_once 'config.php';
require_once 'auth.php';
require_once 'wishlist_action.php';

requireLogin();

// Get wishlist items
$wishlist_items = getWishlistItems($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <?php include 'element/nav.php'; ?>
    
    <div class="container py-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        
        <h1 class="mb-4">My Wishlist</h1>
        
        <?php if (count($wishlist_items) > 0): ?>
        <div class="row">
            <?php foreach ($wishlist_items as $item): ?>
            <div class="col-md-3 mb-4">
                <div class="card product-card h-100">
                    <img src="product_pic/<?php echo $item['image']; ?>" class="card-img-top" alt="<?php echo $item['name']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $item['name']; ?></h5>
                        <p class="card-text">₹<?php echo $item['price']; ?></p>
                        <div class="d-flex justify-content-between">
                            <a href="product_details.php?id=<?php echo $item['id']; ?>" class="btn btn-primary btn-sm">View</a>
                            <form method="post" action="wishlist_action.php">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <button type="submit" name="remove_from_wishlist" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="alert alert-info">
            Your wishlist is empty. <a href="products.php">Browse products</a> to add items to your wishlist.
        </div>
        <?php endif; ?>
    </div>
    
    <?php include 'element/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>