<?php 
require_once 'config.php';
require_once 'product_functions.php';

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = $conn->real_escape_string($_GET['id']);
$product = getProductById($product_id);

if (!$product) {
    header("Location: products.php");
    exit();
}

// Handle add to cart
if (isset($_POST['add_to_cart'])) {
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    addToCart($product_id, $quantity);
    header("Location: cart.php");
    exit();
}

// Handle add to wishlist
if (isset($_POST['add_to_wishlist'])) {
    if (isLoggedIn()) {
        addToWishlist($_SESSION['user_id'], $product_id);
        $_SESSION['message'] = 'Product added to wishlist!';
    } else {
        $_SESSION['message'] = 'Please login to add products to wishlist!';
        header("Location: login.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <?php include 'element/nav.php'; ?>
    
    <div class="container py-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-6">
                <img src="product_pic/<?php echo $product['image']; ?>" class="img-fluid" alt="<?php echo $product['name']; ?>">
            </div>
            <div class="col-md-6">
                <h1><?php echo $product['name']; ?></h1>
                <p class="text-muted">Category: <?php echo $product['category_name']; ?></p>
                <h3 class="my-4">₹<?php echo $product['price']; ?></h3>
                
                <p><?php echo $product['description']; ?></p>
                
                <div class="mt-4">
                    <form method="post">
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Quantity</label>
                            <div class="col-sm-3">
                                <input type="number" name="quantity" class="form-control" value="1" min="1" max="10">
                            </div>
                        </div>
                        <button type="submit" name="add_to_cart" class="btn btn-primary btn-lg mr-2">
                            <i class="fas fa-shopping-cart"></i> Add to Cart
                        </button>
                        <button type="submit" name="add_to_wishlist" class="btn btn-outline-secondary btn-lg">
                            <i class="fas fa-heart"></i> Add to Wishlist
                        </button>
                    </form>
                </div>
                
                <div class="mt-4">
                    <h5>Product Details</h5>
                    <ul>
                        <?php if (!empty($product['brand'])): ?>
                        <li>Brand: <?php echo $product['brand']; ?></li>
                        <?php endif; ?>
                        <?php if (!empty($product['weight'])): ?>
                        <li>Weight: <?php echo $product['weight']; ?></li>
                        <?php endif; ?>
                        <?php if (!empty($product['dimensions'])): ?>
                        <li>Dimensions: <?php echo $product['dimensions']; ?></li>
                        <?php endif; ?>
                        <li>Stock: <?php echo $product['stock'] > 0 ? 'In Stock' : 'Out of Stock'; ?></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Related Products -->
        <div class="mt-5">
            <h3>Related Products</h3>
            <div class="row">
                <?php
                $related_sql = "SELECT * FROM products WHERE category_id = {$product['category_id']} AND id != {$product['id']} LIMIT 4";
                $related_result = $conn->query($related_sql);
                
                if ($related_result->num_rows > 0) {
                    while ($related_row = $related_result->fetch_assoc()) {
                        echo '<div class="col-md-3 mb-4">
                            <div class="card product-card h-100">
                                <img src="product_pic/'.$related_row['image'].'" class="card-img-top" alt="'.$related_row['name'].'">
                                <div class="card-body">
                                    <h5 class="card-title">'.$related_row['name'].'</h5>
                                    <p class="card-text">₹'.$related_row['price'].'</p>
                                    <a href="product_details.php?id='.$related_row['id'].'" class="btn btn-primary">View Details</a>
                                </div>
                            </div>
                        </div>';
                    }
                } else {
                    echo '<div class="col-12"><p>No related products found.</p></div>';
                }
                ?>
            </div>
        </div>
    </div>
    
    <?php include 'element/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>