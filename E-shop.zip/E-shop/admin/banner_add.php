<?php
require_once '../config.php';
require_once '../auth.php';
requireAdmin();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $link = $conn->real_escape_string($_POST['link']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // Handle file upload
    $image = '';
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/banners/";
        $imageFileType = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $image = uniqid() . '.' . $imageFileType;
        $target_file = $target_dir . $image;
        
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    }
    
    $conn->query("INSERT INTO banners (title, image, link, is_active) VALUES ('$title', '$image', '$link', $is_active)");
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Banner added successfully'];
    header('Location: banners.php');
    exit;
}

include 'header.php';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-6">
            <h2>Add New Banner</h2>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="title" class="form-label">Banner Title</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
                
                <div class="mb-3">
                    <label for="image" class="form-label">Banner Image</label>
                    <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                    <div class="form-text">Recommended size: 1200x400 pixels</div>
                </div>
                
                <div class="mb-3">
                    <label for="link" class="form-label">Link URL (optional)</label>
                    <input type="url" class="form-control" id="link" name="link">
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="is_active" name="is_active" checked>
                    <label class="form-check-label" for="is_active">Active</label>
                </div>
                
                <button type="submit" class="btn btn-primary">Save Banner</button>
                <a href="banners.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>