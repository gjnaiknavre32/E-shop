<?php
// element/footer.php
if (!defined('SITE_NAME')) {
    require_once __DIR__ . '/../config.php';
}
?>
<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h5><?php echo SITE_NAME; ?></h5>
                <img src="images/logo-white.png" alt="<?php echo SITE_NAME; ?>" width="120">
            </div>
            
            <div class="col-md-3">
                <h5>Customer Service</h5>
                <ul class="list-unstyled">
                    <li><a href="contact.php" class="text-white">Contact Us</a></li>
                    <li><a href="faq.php" class="text-white">FAQs</a></li>
                    <li><a href="shipping.php" class="text-white">Shipping Policy</a></li>
                    <li><a href="returns.php" class="text-white">Returns Policy</a></li>
                </ul>
            </div>
            
            <div class="col-md-3">
                <h5>My Account</h5>
                <ul class="list-unstyled">
                    <?php if (isLoggedIn()): ?>
                        <li><a href="profile.php" class="text-white">My Profile</a></li>
                        <li><a href="orders.php" class="text-white">My Orders</a></li>
                        <li><a href="wishlist.php" class="text-white">My Wishlist</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="text-white">Login</a></li>
                        <li><a href="register.php" class="text-white">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            
            <div class="col-md-3">
                <h5>Connect With Us</h5>
                <div class="social-icons">
                    <a href="#" class="text-white mr-2"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-white mr-2"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-white mr-2"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-white"><i class="fab fa-pinterest"></i></a>
                </div>
                <div class="mt-3">
                    <p>Subscribe to our newsletter</p>
                    <form class="form-inline">
                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="Your email">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">Subscribe</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <hr class="bg-light">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-right">
                <img src="images/payment-methods.png" alt="Payment Methods" width="200">
            </div>
        </div>
    </div>
</footer>