<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
requireAdmin();

// Handle bulk actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_banners'])) {
        $action = $_POST['bulk_action'];
        $ids = implode(",", array_map('intval', $_POST['selected_banners']));
        
        if ($action == 'delete') {
            // Get image names first
            $images = $conn->query("SELECT image FROM banners WHERE id IN ($ids)")->fetch_all(MYSQLI_ASSOC);
            
            // Delete from database
            if ($conn->query("DELETE FROM banners WHERE id IN ($ids)")) {
                // Delete image files
                foreach ($images as $img) {
                    if (!empty($img['image']) {
                        @unlink("../uploads/banners/" . $img['image']);
                    }
                }
                $_SESSION['message'] = count($_POST['selected_banners']) . ' banners deleted successfully';
            } else {
                $_SESSION['error'] = 'Error deleting banners: ' . $conn->error;
            }
        } elseif ($action == 'activate') {
            $conn->query("UPDATE banners SET is_active = 1 WHERE id IN ($ids)");
            $_SESSION['message'] = count($_POST['selected_banners']) . ' banners activated';
        } elseif ($action == 'deactivate') {
            $conn->query("UPDATE banners SET is_active = 0 WHERE id IN ($ids)");
            $_SESSION['message'] = count($_POST['selected_banners']) . ' banners deactivated';
        }
    } else {
        $_SESSION['error'] = 'No banners selected';
    }
    header("Location: banners.php");
    exit();
}

// Handle single delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $banner = $conn->query("SELECT image FROM banners WHERE id = $id")->fetch_assoc();
    
    if ($conn->query("DELETE FROM banners WHERE id = $id")) {
        if (!empty($banner['image'])) {
            @unlink("../uploads/banners/" . $banner['image']);
        }
        $_SESSION['message'] = 'Banner deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting banner';
    }
    header("Location: banners.php");
    exit();
}

// Sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
$order = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$valid_sorts = ['id', 'title', 'is_active', 'created_at'];
$sort = in_array($sort, $valid_sorts) ? $sort : 'created_at';
$order = $order == 'ASC' ? 'ASC' : 'DESC';

// Get banners
$banners = $conn->query("
    SELECT * FROM banners 
    ORDER BY $sort $order
");

include 'header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'element/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Banner Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="banner_add.php" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Add New Banner
                    </a>
                </div>
            </div>
            
            <?php include 'element/messages.php'; ?>
            
            <form method="post" id="bulkActionForm">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="input-group">
                            <select name="bulk_action" class="form-select" required>
                                <option value="">Bulk Actions</option>
                                <option value="activate">Activate</option>
                                <option value="deactivate">Deactivate</option>
                                <option value="delete">Delete</option>
                            </select>
                            <button type="submit" class="btn btn-outline-primary">Apply</button>
                        </div>
                    </div>
                    <div class="col-md-8 text-end">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="selectAll">
                            <label class="form-check-label" for="selectAll">Select All</label>
                        </div>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="40px"></th>
                                <th>
                                    <a href="?sort=id&order=<?= $sort == 'id' && $order == 'ASC' ? 'DESC' : 'ASC' ?>">
                                        ID <?= $sort == 'id' ? ($order == 'ASC' ? '↑' : '↓') : '' ?>
                                    </a>
                                </th>
                                <th>Image</th>
                                <th>
                                    <a href="?sort=title&order=<?= $sort == 'title' && $order == 'ASC' ? 'DESC' : 'ASC' ?>">
                                        Title <?= $sort == 'title' ? ($order == 'ASC' ? '↑' : '↓') : '' ?>
                                    </a>
                                </th>
                                <th>Link</th>
                                <th>
                                    <a href="?sort=is_active&order=<?= $sort == 'is_active' && $order == 'ASC' ? 'DESC' : 'ASC' ?>">
                                        Status <?= $sort == 'is_active' ? ($order == 'ASC' ? '↑' : '↓') : '' ?>
                                    </a>
                                </th>
                                <th>
                                    <a href="?sort=created_at&order=<?= $sort == 'created_at' && $order == 'ASC' ? 'DESC' : 'ASC' ?>">
                                        Created <?= $sort == 'created_at' ? ($order == 'ASC' ? '↑' : '↓') : '' ?>
                                    </a>
                                </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($banners->num_rows > 0): ?>
                                <?php while ($banner = $banners->fetch_assoc()): ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_banners[]" value="<?= $banner['id'] ?>" class="form-check-input"></td>
                                    <td><?= $banner['id'] ?></td>
                                    <td>
                                        <img src="../uploads/banners/<?= htmlspecialchars($banner['image']) ?>" 
                                             alt="<?= htmlspecialchars($banner['title']) ?>" 
                                             class="img-thumbnail" style="max-width: 100px;">
                                    </td>
                                    <td><?= htmlspecialchars($banner['title']) ?></td>
                                    <td>
                                        <?php if (!empty($banner['link'])): ?>
                                            <a href="<?= htmlspecialchars($banner['link']) ?>" target="_blank">View Link</a>
                                        <?php else: ?>
                                            <span class="text-muted">No link</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= $banner['is_active'] ? 'success' : 'secondary' ?>">
                                            <?= $banner['is_active'] ? 'Active' : 'Inactive' ?>
                                        </span>
                                    </td>
                                    <td><?= date('M d, Y', strtotime($banner['created_at'])) ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="banner_edit.php?id=<?= $banner['id'] ?>" class="btn btn-primary">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="banners.php?delete=<?= $banner['id'] ?>" class="btn btn-danger" 
                                               onclick="return confirm('Are you sure you want to delete this banner?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-5">
                                        <div class="text-muted">No banners found</div>
                                        <a href="banner_add.php" class="btn btn-primary mt-3">
                                            <i class="bi bi-plus-circle"></i> Add First Banner
                                        </a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </main>
    </div>
</div>

<script>
// Select all functionality
document.getElementById('selectAll').addEventListener('change', function() {
    document.querySelectorAll('input[name="selected_banners[]"]').forEach(el => {
        el.checked = this.checked;
    });
});

// Bulk form validation
document.getElementById('bulkActionForm').addEventListener('submit', function(e) {
    const selected = document.querySelectorAll('input[name="selected_banners[]"]:checked').length;
    const action = document.querySelector('select[name="bulk_action"]').value;
    
    if (selected === 0) {
        e.preventDefault();
        alert('Please select at least one banner');
        return false;
    }
    
    if (!action) {
        e.preventDefault();
        alert('Please select a bulk action');
        return false;
    }
    
    if (action === 'delete' && !confirm(`Are you sure you want to delete ${selected} banner(s)?`)) {
        e.preventDefault();
        return false;
    }
});
</script>

<?php include 'footer.php'; ?>