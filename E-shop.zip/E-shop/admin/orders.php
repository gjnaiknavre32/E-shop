<?php
require_once '../config.php';
require_once '../auth.php';

requireAdmin();

// Handle order status update
if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = $conn->real_escape_string($_POST['status']);
    
    // Prepare statement for security
    $sql = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $order_id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = 'Order status updated successfully';
        // Log this activity
        logActivity($conn, $_SESSION['user_id'], "Order Status Updated", "Order #$order_id status changed to $status");
    } else {
        $_SESSION['error'] = 'Error updating order status: ' . $conn->error;
    }
    header("Location: orders.php");
    exit();
}

// Handle bulk actions
if (isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_orders'])) {
        $order_ids = implode(",", array_map('intval', $_POST['selected_orders']));
        $status = $conn->real_escape_string($_POST['bulk_status']);
        
        $sql = "UPDATE orders SET status = ? WHERE id IN ($order_ids)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $status);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Bulk status update successful for ' . count($_POST['selected_orders']) . ' orders';
            logActivity($conn, $_SESSION['user_id'], "Bulk Order Update", "Updated " . count($_POST['selected_orders']) . " orders to $status");
        } else {
            $_SESSION['error'] = 'Error performing bulk action: ' . $conn->error;
        }
        header("Location: orders.php");
        exit();
    } else {
        $_SESSION['error'] = 'No orders selected for bulk action';
        header("Location: orders.php");
        exit();
    }
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';
$search_term = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Build base query
$sql = "SELECT o.*, u.name as user_name, u.email as user_email 
        FROM orders o 
        JOIN users u ON o.user_id = u.id";

// Add filters if specified
$where_clauses = [];
if (!empty($status_filter) && $status_filter != 'all') {
    $where_clauses[] = "o.status = '$status_filter'";
}
if (!empty($search_term)) {
    $where_clauses[] = "(o.id LIKE '%$search_term%' OR 
                        u.name LIKE '%$search_term%' OR 
                        u.email LIKE '%$search_term%' OR
                        o.order_number LIKE '%$search_term%')";
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Complete query with sorting
$sql .= " ORDER BY o.created_at DESC";

// Get all orders
$result = $conn->query($sql);

// Get status counts for filter tabs
$status_counts = [];
$count_result = $conn->query("
    SELECT status, COUNT(*) as count 
    FROM orders 
    GROUP BY status
");
while ($row = $count_result->fetch_assoc()) {
    $status_counts[$row['status']] = $row['count'];
}
$total_orders = array_sum($status_counts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Admin - <?= htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #4e73df;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --secondary: #858796;
        }
        
        .order-status-badge {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.35em 0.65em;
            border-radius: 0.25rem;
        }
        
        .status-pending { background-color: var(--warning); color: #000; }
        .status-processing { background-color: var(--info); color: #fff; }
        .status-shipped { background-color: var(--primary); color: #fff; }
        .status-delivered { background-color: var(--success); color: #fff; }
        .status-cancelled { background-color: var(--danger); color: #fff; }
        .status-completed { background-color: var(--secondary); color: #fff; }
        
        .filter-tab {
            padding: 0.5rem 1rem;
            border-radius: 0.25rem;
            margin-right: 0.5rem;
            font-weight: 600;
            cursor: pointer;
        }
        
        .filter-tab.active {
            background-color: var(--primary);
            color: white;
        }
        
        .order-row:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'element/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Order Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-download"></i> Export
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">CSV</a></li>
                                <li><a class="dropdown-item" href="#">Excel</a></li>
                                <li><a class="dropdown-item" href="#">PDF</a></li>
                            </ul>
                        </div>
                        <a href="order_create.php" class="btn btn-sm btn-primary">
                            <i class="bi bi-plus-circle"></i> Create Order
                        </a>
                    </div>
                </div>
                
                <!-- Messages -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_SESSION['message']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= htmlspecialchars($_SESSION['error']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <!-- Filter Tabs -->
                <div class="d-flex align-items-center mb-4">
                    <div class="me-3">
                        <span class="fw-bold">Filter:</span>
                    </div>
                    <div class="d-flex flex-wrap">
                        <a href="orders.php" class="filter-tab <?= empty($status_filter) || $status_filter == 'all' ? 'active' : '' ?>">
                            All <span class="badge bg-secondary"><?= $total_orders ?></span>
                        </a>
                        <?php foreach ($status_counts as $status => $count): ?>
                            <a href="orders.php?status=<?= $status ?>" class="filter-tab <?= $status_filter == $status ? 'active' : '' ?>">
                                <?= ucfirst($status) ?> <span class="badge bg-secondary"><?= $count ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Search and Bulk Actions -->
                <form method="get" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" placeholder="Search orders..." value="<?= htmlspecialchars($search_term) ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="bi bi-search"></i> Search
                                </button>
                                <?php if (!empty($search_term) || (!empty($status_filter) && $status_filter != 'all')): ?>
                                    <a href="orders.php" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle"></i> Clear
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
                
                <!-- Bulk Action Form -->
                <form method="post" id="bulkActionForm" class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAll">
                                <label class="form-check-label" for="selectAll">Select All</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <select name="bulk_status" class="form-select" required>
                                <option value="">Bulk Action</option>
                                <option value="processing">Mark as Processing</option>
                                <option value="shipped">Mark as Shipped</option>
                                <option value="delivered">Mark as Delivered</option>
                                <option value="cancelled">Mark as Cancelled</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" name="bulk_action" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Apply
                            </button>
                        </div>
                    </div>
                
                    <!-- Orders Table -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="40px"></th>
                                    <th>Order #</th>
                                    <th>Customer</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Payment</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr class="order-row">
                                            <td>
                                                <input class="form-check-input order-checkbox" type="checkbox" name="selected_orders[]" value="<?= $row['id'] ?>">
                                            </td>
                                            <td>
                                                <a href="order_details.php?id=<?= $row['id'] ?>" class="fw-bold">
                                                    #<?= $row['id'] ?>
                                                </a>
                                            </td>
                                            <td>
                                                <div><?= htmlspecialchars($row['user_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($row['user_email']) ?></small>
                                            </td>
                                            <td><?= date('M d, Y h:i A', strtotime($row['created_at'])) ?></td>
                                            <td class="fw-bold">₹<?= number_format($row['total_amount'], 2) ?></td>
                                            <td>
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()" style="width: auto; display: inline-block;">
                                                        <option value="pending" <?= $row['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                                        <option value="processing" <?= $row['status'] == 'processing' ? 'selected' : '' ?>>Processing</option>
                                                        <option value="shipped" <?= $row['status'] == 'shipped' ? 'selected' : '' ?>>Shipped</option>
                                                        <option value="delivered" <?= $row['status'] == 'delivered' ? 'selected' : '' ?>>Delivered</option>
                                                        <option value="cancelled" <?= $row['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                                        <option value="completed" <?= $row['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
                                                    </select>
                                                </form>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">
                                                    <?= ucfirst($row['payment_method']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="order_details.php?id=<?= $row['id'] ?>" class="btn btn-primary" title="View">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <a href="order_edit.php?id=<?= $row['id'] ?>" class="btn btn-outline-secondary" title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="invoice.php?id=<?= $row['id'] ?>" class="btn btn-outline-info" title="Invoice" target="_blank">
                                                        <i class="bi bi-receipt"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-4">
                                            <div class="text-muted">No orders found</div>
                                            <a href="orders.php" class="btn btn-sm btn-outline-primary mt-2">
                                                Reset Filters
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
                
                <!-- Pagination would go here in a real application -->
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Select all checkbox functionality
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.order-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // Bulk form validation
        document.getElementById('bulkActionForm').addEventListener('submit', function(e) {
            const selectedOrders = document.querySelectorAll('.order-checkbox:checked');
            if (selectedOrders.length === 0) {
                e.preventDefault();
                alert('Please select at least one order to perform bulk action');
                return false;
            }
            
            const statusSelect = this.querySelector('[name="bulk_status"]');
            if (statusSelect.value === '') {
                e.preventDefault();
                alert('Please select a bulk action to perform');
                return false;
            }
            
            return confirm(`Are you sure you want to update ${selectedOrders.length} order(s)?`);
        });
    </script>
</body>
</html>