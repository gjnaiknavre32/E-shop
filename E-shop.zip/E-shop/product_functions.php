<?php
require_once 'config.php';

// Get product by ID
function getProductById($id) {
    global $conn;
    $sql = "SELECT p.*, c.name as category_name FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Add to cart
function addToCart($product_id, $quantity = 1) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
}

// Remove from cart
function removeFromCart($product_id) {
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

// Update cart quantity
function updateCartQuantity($product_id, $quantity) {
    if (isset($_SESSION['cart'][$product_id])) {
        if ($quantity > 0) {
            $_SESSION['cart'][$product_id] = $quantity;
        } else {
            removeFromCart($product_id);
        }
    }
}

// Get cart items with product details
function getCartItems() {
    global $conn;
    $cart_items = [];
    
    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        $product_ids = array_keys($_SESSION['cart']);
        $ids_str = implode(',', $product_ids);
        
        $sql = "SELECT * FROM products WHERE id IN ($ids_str)";
        $result = $conn->query($sql);
        
        while ($row = $result->fetch_assoc()) {
            $cart_items[] = [
                'id' => $row['id'],
                'name' => $row['name'],
                'price' => $row['price'],
                'image' => $row['image'],
                'quantity' => $_SESSION['cart'][$row['id']],
                'stock' => $row['stock']
            ];
        }
    }
    
    return $cart_items;
}

// Get cart total
function getCartTotal() {
    $total = 0;
    $cart_items = getCartItems();
    
    foreach ($cart_items as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    
    return $total;
}

// Get products by category
function getProductsByCategory($category_id) {
    global $conn;
    $products = [];
    
    $sql = "SELECT p.*, c.name as category_name FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.category_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    return $products;
}

// Get category by ID
function getCategoryById($id) {
    global $conn;
    $sql = "SELECT * FROM categories WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>