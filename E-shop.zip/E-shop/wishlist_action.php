<?php
require_once 'config.php';
require_once 'auth.php';

// Add to wishlist
function addToWishlist($user_id, $product_id) {
    global $conn;
    
    // Check if already in wishlist
    $sql = "SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        $sql = "INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $user_id, $product_id);
        return $stmt->execute();
    }
    
    return true;
}

// Remove from wishlist
function removeFromWishlist($user_id, $product_id) {
    global $conn;
    
    $sql = "DELETE FROM wishlist WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $product_id);
    return $stmt->execute();
}

// Get wishlist items
function getWishlistItems($user_id) {
    global $conn;
    $items = [];
    
    $sql = "SELECT p.* FROM products p 
            JOIN wishlist w ON p.id = w.product_id 
            WHERE w.user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
    
    return $items;
}

// Handle wishlist actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    requireLogin();
    
    if (isset($_POST['add_to_wishlist'])) {
        $product_id = (int)$_POST['product_id'];
        if (addToWishlist($_SESSION['user_id'], $product_id)) {
            $_SESSION['message'] = 'Product added to wishlist!';
        } else {
            $_SESSION['error'] = 'Failed to add to wishlist.';
        }
    } elseif (isset($_POST['remove_from_wishlist'])) {
        $product_id = (int)$_POST['product_id'];
        if (removeFromWishlist($_SESSION['user_id'], $product_id)) {
            $_SESSION['message'] = 'Product removed from wishlist!';
        } else {
            $_SESSION['error'] = 'Failed to remove from wishlist.';
        }
    }
    
    // Redirect back
    $referer = $_SERVER['HTTP_REFERER'] ?? 'index.php';
    header("Location: $referer");
    exit();
}
?>