<?php 
require_once 'config.php';
require_once 'product_functions.php';

requireLogin();

$cart_items = getCartItems();
$cart_total = getCartTotal();

if (count($cart_items) == 0) {
    header("Location: cart.php");
    exit();
}

// Handle checkout
if (isset($_POST['place_order'])) {
    // Get user details
    $user_id = $_SESSION['user_id'];
    $address = $conn->real_escape_string($_POST['address']);
    $city = $conn->real_escape_string($_POST['city']);
    $state = $conn->real_escape_string($_POST['state']);
    $zip = $conn->real_escape_string($_POST['zip']);
    $payment_method = $conn->real_escape_string($_POST['payment_method']);
    $total_amount = $cart_total;
    
    // Create order
    $sql = "INSERT INTO orders (user_id, address, city, state, zip, payment_method, total_amount, status) 
            VALUES ('$user_id', '$address', '$city', '$state', '$zip', '$payment_method', '$total_amount', 'pending')";
    
    if ($conn->query($sql)) {
        $order_id = $conn->insert_id;
        
        // Add order items
        foreach ($cart_items as $item) {
            $product_id = $item['id'];
            $quantity = $item['quantity'];
            $price = $item['price'];
            
            $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                    VALUES ('$order_id', '$product_id', '$quantity', '$price')";
            $conn->query($sql);
            
            // Update product stock
            $sql = "UPDATE products SET stock = stock - $quantity WHERE id = $product_id";
            $conn->query($sql);
        }
        
        // Clear cart
        unset($_SESSION['cart']);
        
        // Redirect to order confirmation
        $_SESSION['message'] = 'Order placed successfully!';
        header("Location: order_confirmation.php?id=$order_id");
        exit();
    } else {
        $_SESSION['error'] = 'Error placing order. Please try again.';
    }
}

// Get user details
$user_sql = "SELECT * FROM users WHERE id = {$_SESSION['user_id']}";
$user_result = $conn->query($user_sql);
$user = $user_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <?php include 'element/nav.php'; ?>
    
    <div class="container py-5">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <h1 class="mb-4">Checkout</h1>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Shipping Information</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="checkout.php">
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" class="form-control" value="<?php echo $user['name']; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" value="<?php echo $user['email']; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <textarea name="address" class="form-control" required><?php echo $user['address'] ?? ''; ?></textarea>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>City</label>
                                    <input type="text" name="city" class="form-control" value="<?php echo $user['city'] ?? ''; ?>" required>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>State</label>
                                    <input type="text" name="state" class="form-control" value="<?php echo $user['state'] ?? ''; ?>" required>
                                </div>
                                <div class="form-group col-md-2">
                                    <label>ZIP Code</label>
                                    <input type="text" name="zip" class="form-control" value="<?php echo $user['zip'] ?? ''; ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Payment Method</label>
                                <select name="payment_method" class="form-control" required>
                                    <option value="cod">Cash on Delivery</option>
                                    <option value="credit_card">Credit Card</option>
                                    <option value="paypal">PayPal</option>
                                </select>
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4>Order Summary</h4>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $item): ?>
                                <tr>
                                    <td><?php echo $item['name']; ?> × <?php echo $item['quantity']; ?></td>
                                    <td>₹<?php echo $item['price'] * $item['quantity']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Total</th>
                                    <th>₹<?php echo $cart_total; ?></th>
                                </tr>
                            </tfoot>
                        </table>
                        
                        <button type="submit" name="place_order" class="btn btn-primary btn-block">Place Order</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include 'element/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>