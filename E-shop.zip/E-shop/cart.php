<?php 
require_once 'config.php';
require_once 'product_functions.php';

// Handle remove from cart
if (isset($_GET['remove'])) {
    removeFromCart($_GET['remove']);
    header("Location: cart.php");
    exit();
}

// Handle update quantity
if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $product_id => $quantity) {
        updateCartQuantity($product_id, $quantity);
    }
    $_SESSION['message'] = 'Cart updated successfully!';
    header("Location: cart.php");
    exit();
}

$cart_items = getCartItems();
$cart_total = getCartTotal();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <?php include 'element/nav.php'; ?>
    
    <div class="container py-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        
        <h1 class="mb-4">Shopping Cart</h1>
        
        <?php if (count($cart_items) > 0): ?>
        <form method="post" action="cart.php">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="product_pic/<?php echo $item['image']; ?>" width="60" class="mr-3" alt="<?php echo $item['name']; ?>">
                                    <div><?php echo $item['name']; ?></div>
                                </div>
                            </td>
                            <td>₹<?php echo $item['price']; ?></td>
                            <td>
                                <input type="number" name="quantity[<?php echo $item['id']; ?>]" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['stock']; ?>" class="form-control" style="width: 80px;">
                            </td>
                            <td>₹<?php echo $item['price'] * $item['quantity']; ?></td>
                            <td>
                                <a href="cart.php?remove=<?php echo $item['id']; ?>" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right"><strong>Total:</strong></td>
                            <td colspan="2"><strong>₹<?php echo $cart_total; ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="products.php" class="btn btn-outline-primary">Continue Shopping</a>
                <div>
                    <button type="submit" name="update_cart" class="btn btn-secondary mr-2">Update Cart</button>
                    <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>
                </div>
            </div>
        </form>
        <?php else: ?>
        <div class="alert alert-info">
            Your shopping cart is empty. <a href="products.php">Continue shopping</a>.
        </div>
        <?php endif; ?>
    </div>
    
    <?php include 'element/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>