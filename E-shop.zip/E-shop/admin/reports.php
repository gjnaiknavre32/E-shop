<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
requireAdmin();

// Date range - default last 30 days
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Validate dates
if (strtotime($start_date) > strtotime($end_date)) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// Sales report
$sales_report = $conn->query("
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as order_count,
        SUM(total) as total_sales,
        AVG(total) as avg_order_value
    FROM orders
    WHERE created_at BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
    GROUP BY DATE(created_at)
    ORDER BY date ASC
");

// Top products
$top_products = $conn->query("
    SELECT 
        p.name,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.price * oi.quantity) as total_revenue
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.created_at BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
    GROUP BY p.id
    ORDER BY total_revenue DESC
    LIMIT 5
");

// Sales by category
$sales_by_category = $conn->query("
    SELECT 
        c.name as category,
        SUM(oi.price * oi.quantity) as total_revenue
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN categories c ON p.category_id = c.id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.created_at BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
    GROUP BY c.id
    ORDER BY total_revenue DESC
");

// Coupon usage
$coupon_usage = $conn->query("
    SELECT 
        coupon_code,
        COUNT(*) as usage_count,
        SUM(total) as total_discount
    FROM orders
    WHERE coupon_code IS NOT NULL 
    AND created_at BETWEEN '$start_date 00:00:00' AND '$end_date 23:59:59'
    GROUP BY coupon_code
    ORDER BY usage_count DESC
");


?>

<div class="container-fluid">
    <div class="row">
        <?php include 'element/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Sales Reports</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="reports_export.php?start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" 
                           class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-download"></i> Export
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Date Filter -->
            <form method="GET" class="row g-3 mb-4">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">From Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" 
                           value="<?= $start_date ?>" max="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">To Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" 
                           value="<?= $end_date ?>" max="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-filter"></i> Apply Filter
                    </button>
                </div>
                <div class="col-md-4 d-flex align-items-end justify-content-end">
                    <div class="btn-group">
                        <a href="?start_date=<?= date('Y-m-d', strtotime('-7 days')) ?>&end_date=<?= date('Y-m-d') ?>" 
                           class="btn btn-sm btn-outline-secondary">Last 7 Days</a>
                        <a href="?start_date=<?= date('Y-m-d', strtotime('-30 days')) ?>&end_date=<?= date('Y-m-d') ?>" 
                           class="btn btn-sm btn-outline-secondary">Last 30 Days</a>
                        <a href="?start_date=<?= date('Y-m-01') ?>&end_date=<?= date('Y-m-d') ?>" 
                           class="btn btn-sm btn-outline-secondary">This Month</a>
                    </div>
                </div>
            </form>
            
            <!-- Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body">
                            <h6 class="card-title">Total Orders</h6>
                            <h3 class="card-text">
                                <?= number_format($sales_report->num_rows) ?>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body">
                            <h6 class="card-title">Total Revenue</h6>
                            <h3 class="card-text">
                                ₹<?= number_format(array_sum(array_column($sales_report->fetch_all(MYSQLI_ASSOC), 'total_sales')), 2) ?>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card bg-info text-white h-100">
                        <div class="card-body">
                            <h6 class="card-title">Avg. Order Value</h6>
                            <h3 class="card-text">
                                ₹<?= number_format($sales_report->num_rows > 0 ? 
                                    array_sum(array_column($sales_report->fetch_all(MYSQLI_ASSOC), 'total_sales')) / $sales_report->num_rows : 0, 2) ?>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card bg-warning text-dark h-100">
                        <div class="card-body">
                            <h6 class="card-title">Coupon Savings</h6>
                            <h3 class="card-text">
                                ₹<?= number_format(array_sum(array_column($coupon_usage->fetch_all(MYSQLI_ASSOC), 'total_discount')), 2) ?>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Charts Row -->
            <div class="row mb-4">
                <div class="col-lg-8">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Sales Trend</h6>
                        </div>
                        <div class="card-body">
                            <div class="chart-area">
                                <canvas id="salesChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Top Products</h6>
                        </div>
                        <div class="card-body">
                            <div class="chart-pie pt-4 pb-2">
                                <canvas id="topProductsChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Detailed Reports -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Sales by Category</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Revenue</th>
                                            <th>% of Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $total_revenue = array_sum(array_column($sales_by_category->fetch_all(MYSQLI_ASSOC), 'total_revenue'));
                                        $sales_by_category->data_seek(0); // Reset pointer
                                        ?>
                                        <?php while($cat = $sales_by_category->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $cat['category'] ?></td>
                                            <td>₹<?= number_format($cat['total_revenue'], 2) ?></td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" 
                                                         style="width: <?= $total_revenue > 0 ? ($cat['total_revenue'] / $total_revenue * 100) : 0 ?>%">
                                                        <?= $total_revenue > 0 ? round($cat['total_revenue'] / $total_revenue * 100, 1) : 0 ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Coupon Usage</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Coupon Code</th>
                                            <th>Times Used</th>
                                            <th>Total Discount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($coupon = $coupon_usage->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $coupon['coupon_code'] ?></td>
                                            <td><?= $coupon['usage_count'] ?></td>
                                            <td>₹<?= number_format($coupon['total_discount'], 2) ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Sales Chart
const salesCtx = document.getElementById('salesChart').getContext('2d');
const salesChart = new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($sales_report->fetch_all(MYSQLI_ASSOC), 'date')) ?>,
        datasets: [{
            label: 'Daily Sales',
            data: <?= json_encode(array_column($sales_report->fetch_all(MYSQLI_ASSOC), 'total_sales')) ?>,
            backgroundColor: 'rgba(78, 115, 223, 0.05)',
            borderColor: 'rgba(78, 115, 223, 1)',
            pointBackgroundColor: 'rgba(78, 115, 223, 1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(78, 115, 223, 1)',
            tension: 0.3,
            fill: true
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₹' + value.toLocaleString();
                    }
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return '₹' + context.parsed.y.toLocaleString();
                    }
                }
            }
        }
    }
});

// Top Products Chart
const topProductsCtx = document.getElementById('topProductsChart').getContext('2d');
const topProductsChart = new Chart(topProductsCtx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($top_products->fetch_all(MYSQLI_ASSOC), 'name')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($top_products->fetch_all(MYSQLI_ASSOC), 'total_revenue')) ?>,
            backgroundColor: [
                '#4e73df',
                '#1cc88a',
                '#36b9cc',
                '#f6c23e',
                '#e74a3b'
            ],
            hoverBackgroundColor: [
                '#2e59d9',
                '#17a673',
                '#2c9faf',
                '#dda20a',
                '#be2617'
            ],
            hoverBorderColor: "rgba(234, 236, 244, 1)",
        }],
    },
    options: {
        maintainAspectRatio: false,
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return '₹' + context.raw.toLocaleString();
                    }
                }
            },
            legend: {
                position: 'bottom'
            }
        },
        cutout: '70%',
    },
});
</script>

<?php include 'footer.php'; ?>