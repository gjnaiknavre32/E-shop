
            
            
          <?php
// sidebar.php - Admin Panel Sidebar Component
?>
<nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
    <div class="sidebar-brand">
        <i class="bi bi-shop"></i> <?= htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8') ?>
    </div>
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : '' ?>" href="orders.php">
                    <i class="bi bi-cart-check"></i> Orders
                    <span class="badge bg-danger float-end" id="pending-orders-count">0</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : '' ?>" href="products.php">
                    <i class="bi bi-box-seam"></i> Products
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : '' ?>" href="categories.php">
                    <i class="bi bi-tags"></i> Categories
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : '' ?>" href="users.php">
                    <i class="bi bi-people"></i> Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= in_array(basename($_SERVER['PHP_SELF']), ['banners.php', 'banner_add.php', 'banner_edit.php']) ? 'active' : '' ?>" href="banners.php">
                    <i class="bi bi-images me-2"></i>Banners
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?= in_array(basename($_SERVER['PHP_SELF']), ['coupons.php', 'coupon_add.php', 'coupon_edit.php']) ? 'active' : '' ?>" href="coupons.php">
                    <i class="bi bi-percent me-2"></i>Coupons
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : '' ?>" href="reports.php">
                    <i class="bi bi-graph-up"></i> Reports
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : '' ?>" href="settings.php">
                    <i class="bi bi-gear"></i> Settings
                </a>
            </li>
        </ul>
        
        <div class="mt-4 px-3">
            <div class="text-white small fw-bold">QUICK ACTIONS</div>
            <div class="d-grid gap-2 mt-2">
                <a href="product_add.php" class="btn btn-sm btn-outline-light">
                    <i class="bi bi-plus-circle"></i> Add Product
                </a>
                <a href="order_create.php" class="btn btn-sm btn-outline-light">
                    <i class="bi bi-plus-circle"></i> Create Order
                </a>
            </div>
        </div>
    </div>
</nav>

<style>
    /* Sidebar specific styles */
    .sidebar {
        min-height: 100vh;
        background: linear-gradient(180deg, var(--primary) 0%, #224abe 100%);
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    }
    
    .sidebar .nav-link {
        color: rgba(255, 255, 255, 0.8);
        font-weight: 600;
        padding: 0.50rem;
        margin-bottom: 0.2rem;
        border-radius: 0.35rem;
        transition: all 0.3s;
    }
    
    .sidebar .nav-link:hover, 
    .sidebar .nav-link.active {
        color: white;
        background-color: rgba(255, 255, 255, 0.2);
    }
    
    .sidebar .nav-link i {
        margin-right: 0.5rem;
        font-size: 1.1rem;
    }
    
    .sidebar-brand {
        height: 4.375rem;
        text-decoration: none;
        font-size: 1.2rem;
        font-weight: 800;
        padding: 1.5rem 1rem;
        text-align: center;
        letter-spacing: 0.05rem;
        z-index: 1;
        color: rgba(255, 255, 255, 0.8);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .sidebar .badge {
        font-size: 0.6rem;
        padding: 0.25em 0.4em;
        margin-top: 0.2rem;
    }
</style>

<script>
// You can add dynamic functionality here
document.addEventListener('DOMContentLoaded', function() {
    // Example: Fetch pending orders count via AJAX
    fetchPendingOrdersCount();
    
    function fetchPendingOrdersCount() {
        fetch('../api/get_pending_orders.php')
            .then(response => response.json())
            .then(data => {
                if(data.count > 0) {
                    document.getElementById('pending-orders-count').textContent = data.count;
                    document.getElementById('pending-orders-count').style.display = 'inline-block';
                }
            })
            .catch(error => console.error('Error fetching pending orders:', error));
    }
    
    // Update every 5 minutes
    setInterval(fetchPendingOrdersCount, 300000);
});
</script>