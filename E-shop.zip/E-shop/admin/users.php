<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

requireAdmin();

// Handle user actions
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // Cannot delete admin user
    if ($id == 1) {
        $_SESSION['error'] = 'Cannot delete the main admin user';
        logActivity($conn, $_SESSION['user_id'], "Delete Attempt", "Tried to delete admin user ID 1");
    } else {
        // Use prepared statement for security
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'User deleted successfully';
            logActivity($conn, $_SESSION['user_id'], "User Deleted", "User ID $id deleted");
        } else {
            $_SESSION['error'] = 'Error deleting user: ' . $conn->error;
        }
    }
    header("Location: users.php");
    exit();
}

// Handle role update
if (isset($_POST['update_role'])) {
    $id = (int)$_POST['user_id'];
    $role = $conn->real_escape_string($_POST['role']);
    
    // Cannot change role of admin user
    if ($id == 1) {
        $_SESSION['error'] = 'Cannot change role of the main admin user';
        logActivity($conn, $_SESSION['user_id'], "Role Change Attempt", "Tried to change admin user ID 1 role");
    } else {
        $sql = "UPDATE users SET role = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $role, $id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'User role updated successfully';
            logActivity($conn, $_SESSION['user_id'], "User Role Updated", "User ID $id role changed to $role");
        } else {
            $_SESSION['error'] = 'Error updating user role: ' . $conn->error;
        }
    }
    header("Location: users.php");
    exit();
}

// Handle bulk actions
if (isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_users'])) {
        $user_ids = implode(",", array_map('intval', $_POST['selected_users']));
        $action = $conn->real_escape_string($_POST['bulk_action']);
        
        // Exclude admin user (ID 1) from bulk actions
        $user_ids = preg_replace('/(^|,)1(,|$)/', '$1', $user_ids);
        $user_ids = trim($user_ids, ',');
        
        if (empty($user_ids)) {
            $_SESSION['error'] = 'No valid users selected for bulk action';
            header("Location: users.php");
            exit();
        }
        
        if ($action == 'delete') {
            $sql = "DELETE FROM users WHERE id IN ($user_ids)";
            $success_msg = count($_POST['selected_users']) . ' users deleted successfully';
        } elseif ($action == 'make_admin') {
            $sql = "UPDATE users SET role = 'admin' WHERE id IN ($user_ids)";
            $success_msg = count($_POST['selected_users']) . ' users promoted to admin';
        } elseif ($action == 'make_user') {
            $sql = "UPDATE users SET role = 'user' WHERE id IN ($user_ids)";
            $success_msg = count($_POST['selected_users']) . ' admins demoted to user';
        }
        
        if ($conn->query($sql)) {
            $_SESSION['message'] = $success_msg;
            logActivity($conn, $_SESSION['user_id'], "Bulk User Action", "Action: $action on " . count($_POST['selected_users']) . " users");
        } else {
            $_SESSION['error'] = 'Error performing bulk action: ' . $conn->error;
        }
        header("Location: users.php");
        exit();
    } else {
        $_SESSION['error'] = 'No users selected for bulk action';
        header("Location: users.php");
        exit();
    }
}

// Get all users
$sql = "SELECT id, name, email, role, created_at, is_active FROM users ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin - <?= htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #4e73df;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --secondary: #858796;
        }
        
        .user-role-badge {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.35em 0.65em;
        }
        
        .role-admin {
            background-color: var(--primary);
            color: white;
        }
        
        .role-user {
            background-color: var(--secondary);
            color: white;
        }
        
        .status-active {
            color: var(--success);
        }
        
        .status-inactive {
            color: var(--danger);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'element/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">User Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="user_add.php" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Add User
                        </a>
                    </div>
                </div>
                
                <!-- Messages -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_SESSION['message']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= htmlspecialchars($_SESSION['error']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <!-- Bulk Action Form -->
                <form method="post" id="bulkActionForm" class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAll">
                                <label class="form-check-label" for="selectAll">Select All</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select name="bulk_action" class="form-select" required>
                                <option value="">Bulk Action</option>
                                <option value="make_admin">Make Admin</option>
                                <option value="make_user">Make Regular User</option>
                                <option value="delete">Delete Selected</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Apply
                            </button>
                        </div>
                    </div>
                
                    <!-- Users Table -->
                    <div class="table-responsive mt-3">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="40px"></th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Joined</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <?php if ($row['id'] != 1): ?>
                                                    <input class="form-check-input user-checkbox" type="checkbox" 
                                                           name="selected_users[]" value="<?= $row['id'] ?>">
                                                <?php endif; ?>
                                            </td>
                                            <td><?= $row['id'] ?></td>
                                            <td><?= htmlspecialchars($row['name']) ?></td>
                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                            <td>
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="user_id" value="<?= $row['id'] ?>">
                                                    <select name="role" class="form-select form-select-sm" <?= $row['id'] == 1 ? 'disabled' : '' ?> onchange="this.form.submit()">
                                                        <option value="admin" <?= $row['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                                                        <option value="user" <?= $row['role'] == 'user' ? 'selected' : '' ?>>User</option>
                                                    </select>
                                                </form>
                                            </td>
                                            <td class="<?= $row['is_active'] ? 'status-active' : 'status-inactive' ?>">
                                                <?= $row['is_active'] ? 'Active' : 'Inactive' ?>
                                            </td>
                                            <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="user_edit.php?id=<?= $row['id'] ?>" class="btn btn-primary" title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="users.php?delete=<?= $row['id'] ?>" class="btn btn-danger" 
                                                       title="Delete" onclick="return confirm('Are you sure you want to delete this user?')" <?= $row['id'] == 1 ? 'disabled' : '' ?>>
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-4">
                                            <div class="text-muted">No users found</div>
                                            <a href="user_add.php" class="btn btn-sm btn-primary mt-2">
                                                <i class="bi bi-plus-circle"></i> Add First User
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Select all checkbox functionality
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.user-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // Bulk form validation
        document.getElementById('bulkActionForm').addEventListener('submit', function(e) {
            const selectedUsers = document.querySelectorAll('.user-checkbox:checked');
            if (selectedUsers.length === 0) {
                e.preventDefault();
                alert('Please select at least one user to perform bulk action');
                return false;
            }
            
            const actionSelect = this.querySelector('[name="bulk_action"]');
            if (actionSelect.value === '') {
                e.preventDefault();
                alert('Please select a bulk action to perform');
                return false;
            }
            
            if (actionSelect.value === 'delete') {
                return confirm(`Are you sure you want to delete ${selectedUsers.length} user(s)? This cannot be undone.`);
            }
            
            return true;
        });
    </script>
</body>
</html>