<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';

requireAdmin();

// Handle product actions
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // Use prepared statement for security
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = 'Product deleted successfully';
        logActivity($conn, $_SESSION['user_id'], "Product Deleted", "Product ID: $id deleted");
    } else {
        $_SESSION['error'] = 'Error deleting product: ' . $conn->error;
    }
    header("Location: products.php");
    exit();
}

// Handle bulk actions
if (isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_products'])) {
        $product_ids = implode(",", array_map('intval', $_POST['selected_products']));
        $action = $conn->real_escape_string($_POST['bulk_action']);
        
        if ($action == 'delete') {
            $sql = "DELETE FROM products WHERE id IN ($product_ids)";
            $success_msg = count($_POST['selected_products']) . ' products deleted successfully';
        } elseif ($action == 'feature') {
            $sql = "UPDATE products SET featured = 1 WHERE id IN ($product_ids)";
            $success_msg = count($_POST['selected_products']) . ' products marked as featured';
        } elseif ($action == 'unfeature') {
            $sql = "UPDATE products SET featured = 0 WHERE id IN ($product_ids)";
            $success_msg = count($_POST['selected_products']) . ' products unmarked as featured';
        }
        
        if ($conn->query($sql)) {
            $_SESSION['message'] = $success_msg;
            logActivity($conn, $_SESSION['user_id'], "Bulk Product Action", "Action: $action on " . count($_POST['selected_products']) . " products");
        } else {
            $_SESSION['error'] = 'Error performing bulk action: ' . $conn->error;
        }
        header("Location: products.php");
        exit();
    } else {
        $_SESSION['error'] = 'No products selected for bulk action';
        header("Location: products.php");
        exit();
    }
}

// Get filter parameters
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$featured_filter = isset($_GET['featured']) ? (int)$_GET['featured'] : -1;
$stock_filter = isset($_GET['stock']) ? $_GET['stock'] : 'all';
$search_term = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Build base query
$sql = "SELECT p.*, c.name as category_name FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id";

// Add filters if specified
$where_clauses = [];
if (!empty($search_term)) {
    $where_clauses[] = "(p.name LIKE '%$search_term%' OR p.description LIKE '%$search_term%')";
}
if ($category_filter > 0) {
    $where_clauses[] = "p.category_id = $category_filter";
}
if ($featured_filter >= 0) {
    $where_clauses[] = "p.featured = $featured_filter";
}
if ($stock_filter == 'low') {
    $where_clauses[] = "p.stock < 10";
} elseif ($stock_filter == 'out') {
    $where_clauses[] = "p.stock = 0";
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Complete query with sorting
$sql .= " ORDER BY p.created_at DESC";

// Get all products
$result = $conn->query($sql);

// Get all categories for filter dropdown
$categories = $conn->query("SELECT id, name FROM categories ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Admin - <?= htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #4e73df;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --secondary: #858796;
        }
        
        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }
        
        .stock-low {
            color: var(--danger);
            font-weight: 600;
        }
        
        .stock-out {
            text-decoration: line-through;
            color: var(--secondary);
        }
        
        .filter-tab {
            padding: 0.5rem 1rem;
            border-radius: 0.25rem;
            margin-right: 0.5rem;
            font-weight: 600;
            cursor: pointer;
        }
        
        .filter-tab.active {
            background-color: var(--primary);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'element/sidebar.php'; ?>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Product Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="product_add.php" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Add Product
                        </a>
                    </div>
                </div>
                
                <!-- Messages -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_SESSION['message']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= htmlspecialchars($_SESSION['error']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <!-- Filters -->
                <form method="get" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="search" placeholder="Search products..." 
                                   value="<?= htmlspecialchars($search_term) ?>">
                        </div>
                        <div class="col-md-2">
                            <select name="category" class="form-select">
                                <option value="0">All Categories</option>
                                <?php while ($cat = $categories->fetch_assoc()): ?>
                                    <option value="<?= $cat['id'] ?>" <?= $category_filter == $cat['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['name']) ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="featured" class="form-select">
                                <option value="-1">Featured Status</option>
                                <option value="1" <?= $featured_filter === '1' ? 'selected' : '' ?>>Featured Only</option>
                                <option value="0" <?= $featured_filter === '0' ? 'selected' : '' ?>>Not Featured</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="stock" class="form-select">
                                <option value="all" <?= $stock_filter == 'all' ? 'selected' : '' ?>>All Stock</option>
                                <option value="low" <?= $stock_filter == 'low' ? 'selected' : '' ?>>Low Stock (<10)</option>
                                <option value="out" <?= $stock_filter == 'out' ? 'selected' : '' ?>>Out of Stock</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-funnel"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
                
                <!-- Bulk Action Form -->
                <form method="post" id="bulkActionForm" class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAll">
                                <label class="form-check-label" for="selectAll">Select All</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select name="bulk_action" class="form-select" required>
                                <option value="">Bulk Action</option>
                                <option value="feature">Mark as Featured</option>
                                <option value="unfeature">Remove Featured</option>
                                <option value="delete">Delete Selected</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Apply
                            </button>
                        </div>
                    </div>
                
                    <!-- Products Table -->
                    <div class="table-responsive mt-3">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="40px"></th>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Featured</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <input class="form-check-input product-checkbox" type="checkbox" 
                                                       name="selected_products[]" value="<?= $row['id'] ?>">
                                            </td>
                                            <td><?= $row['id'] ?></td>
                                            <td>
                                                <img src="../product_pic/<?= htmlspecialchars($row['image']) ?>" 
                                                     class="product-img" alt="<?= htmlspecialchars($row['name']) ?>">
                                            </td>
                                            <td>
                                                <div class="fw-bold"><?= htmlspecialchars($row['name']) ?></div>
                                                <small class="text-muted"><?= substr(htmlspecialchars($row['description']), 0, 50) ?>...</small>
                                            </td>
                                            <td><?= htmlspecialchars($row['category_name'] ?? 'Uncategorized') ?></td>
                                            <td class="fw-bold">₹<?= number_format($row['price'], 2) ?></td>
                                            <td class="<?= $row['stock'] < 10 ? 'stock-low' : '' ?> <?= $row['stock'] == 0 ? 'stock-out' : '' ?>">
                                                <?= $row['stock'] ?>
                                            </td>
                                            <td>
                                                <?php if ($row['featured']): ?>
                                                    <span class="badge bg-success">Yes</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">No</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="product_edit.php?id=<?= $row['id'] ?>" class="btn btn-primary" title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="products.php?delete=<?= $row['id'] ?>" class="btn btn-danger" 
                                                       title="Delete" onclick="return confirm('Are you sure you want to delete this product?')">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                    <a href="../product.php?id=<?= $row['id'] ?>" class="btn btn-info" title="View" target="_blank">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center py-4">
                                            <div class="text-muted">No products found</div>
                                            <a href="products.php" class="btn btn-sm btn-outline-primary mt-2">
                                                Reset Filters
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
                
                <!-- Pagination would go here in a real application -->
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Select all checkbox functionality
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.product-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // Bulk form validation
        document.getElementById('bulkActionForm').addEventListener('submit', function(e) {
            const selectedProducts = document.querySelectorAll('.product-checkbox:checked');
            if (selectedProducts.length === 0) {
                e.preventDefault();
                alert('Please select at least one product to perform bulk action');
                return false;
            }
            
            const actionSelect = this.querySelector('[name="bulk_action"]');
            if (actionSelect.value === '') {
                e.preventDefault();
                alert('Please select a bulk action to perform');
                return false;
            }
            
            if (actionSelect.value === 'delete') {
                return confirm(`Are you sure you want to delete ${selectedProducts.length} product(s)? This cannot be undone.`);
            }
            
            return true;
        });
    </script>
</body>
</html>