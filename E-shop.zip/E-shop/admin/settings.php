<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
requireAdmin();

// Get all settings
$settings = $conn->query("SELECT * FROM settings")->fetch_all(MYSQLI_ASSOC);
$settings = array_column($settings, 'value', 'name');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST as $key => $value) {
        if (array_key_exists($key, $settings)) {
            $value = $conn->real_escape_string($value);
            $conn->query("UPDATE settings SET value = '$value' WHERE name = '$key'");
        }
    }
    
    // Handle file uploads
    if (!empty($_FILES['site_logo']['name'])) {
        $logo = uploadFile('site_logo', '../uploads/');
        if ($logo) {
            $conn->query("UPDATE settings SET value = '$logo' WHERE name = 'site_logo'");
        }
    }
    
    if (!empty($_FILES['site_favicon']['name'])) {
        $favicon = uploadFile('site_favicon', '../uploads/');
        if ($favicon) {
            $conn->query("UPDATE settings SET value = '$favicon' WHERE name = 'site_favicon'");
        }
    }
    
    $_SESSION['message'] = 'Settings updated successfully';
    header("Location: settings.php");
    exit();
}

function uploadFile($field, $target_dir) {
    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK) return false;
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = uniqid() . '.' . $ext;
    $target_file = $target_dir . $filename;
    
    // Check image file type
    $valid_exts = ['jpg', 'jpeg', 'png', 'gif', 'ico'];
    if (!in_array($ext, $valid_exts)) return false;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return $filename;
    }
    return false;
}


?>

<div class="container-fluid">
    <div class="row">
        <?php include 'element/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">System Settings</h1>
            </div>
            
            <?php include 'element/messages.php'; ?>
            
            <form method="post" enctype="multipart/form-data">
                <ul class="nav nav-tabs mb-4" id="settingsTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button">
                            <i class="bi bi-gear"></i> General
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="email-tab" data-bs-toggle="tab" data-bs-target="#email" type="button">
                            <i class="bi bi-envelope"></i> Email
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="payment-tab" data-bs-toggle="tab" data-bs-target="#payment" type="button">
                            <i class="bi bi-credit-card"></i> Payment
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="seo-tab" data-bs-toggle="tab" data-bs-target="#seo" type="button">
                            <i class="bi bi-search"></i> SEO
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="maintenance-tab" data-bs-toggle="tab" data-bs-target="#maintenance" type="button">
                            <i class="bi bi-tools"></i> Maintenance
                        </button>
                    </li>
                </ul>
                
                <div class="tab-content" id="settingsTabsContent">
                    <!-- General Settings Tab -->
                    <div class="tab-pane fade show active" id="general" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="site_name" class="form-label">Site Name</label>
                                    <input type="text" class="form-control" id="site_name" name="site_name" 
                                           value="<?= htmlspecialchars($settings['site_name']) ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="site_email" class="form-label">Admin Email</label>
                                    <input type="email" class="form-control" id="site_email" name="site_email" 
                                           value="<?= htmlspecialchars($settings['site_email']) ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="site_phone" class="form-label">Contact Phone</label>
                                    <input type="text" class="form-control" id="site_phone" name="site_phone" 
                                           value="<?= htmlspecialchars($settings['site_phone']) ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="site_address" class="form-label">Address</label>
                                    <textarea class="form-control" id="site_address" name="site_address" rows="3"><?= htmlspecialchars($settings['site_address']) ?></textarea>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="site_logo" class="form-label">Site Logo</label>
                                    <input type="file" class="form-control" id="site_logo" name="site_logo" accept="image/*">
                                    <?php if (!empty($settings['site_logo'])): ?>
                                        <div class="mt-2">
                                            <img src="../uploads/<?= htmlspecialchars($settings['site_logo']) ?>" class="img-thumbnail" style="max-height: 100px;">
                                            <div class="form-text">Current logo</div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="site_favicon" class="form-label">Favicon</label>
                                    <input type="file" class="form-control" id="site_favicon" name="site_favicon" accept="image/x-icon,.ico">
                                    <?php if (!empty($settings['site_favicon'])): ?>
                                        <div class="mt-2">
                                            <img src="../uploads/<?= htmlspecialchars($settings['site_favicon']) ?>" class="img-thumbnail" style="max-height: 32px;">
                                            <div class="form-text">Current favicon</div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="items_per_page" class="form-label">Items Per Page</label>
                                    <input type="number" class="form-control" id="items_per_page" name="items_per_page" 
                                           value="<?= htmlspecialchars($settings['items_per_page']) ?>" min="5" max="100" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Email Settings Tab -->
                    <div class="tab-pane fade" id="email" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="smtp_host" class="form-label">SMTP Host</label>
                                    <input type="text" class="form-control" id="smtp_host" name="smtp_host" 
                                           value="<?= htmlspecialchars($settings['smtp_host']) ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="smtp_port" class="form-label">SMTP Port</label>
                                    <input type="number" class="form-control" id="smtp_port" name="smtp_port" 
                                           value="<?= htmlspecialchars($settings['smtp_port']) ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="smtp_username" class="form-label">SMTP Username</label>
                                    <input type="text" class="form-control" id="smtp_username" name="smtp_username" 
                                           value="<?= htmlspecialchars($settings['smtp_username']) ?>">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="smtp_password" class="form-label">SMTP Password</label>
                                    <input type="password" class="form-control" id="smtp_password" name="smtp_password" 
                                           value="<?= htmlspecialchars($settings['smtp_password']) ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="smtp_encryption" class="form-label">Encryption</label>
                                    <select class="form-select" id="smtp_encryption" name="smtp_encryption">
                                        <option value="">None</option>
                                        <option value="ssl" <?= $settings['smtp_encryption'] == 'ssl' ? 'selected' : '' ?>>SSL</option>
                                        <option value="tls" <?= $settings['smtp_encryption'] == 'tls' ? 'selected' : '' ?>>TLS</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email_from" class="form-label">From Email</label>
                                    <input type="email" class="form-control" id="email_from" name="email_from" 
                                           value="<?= htmlspecialchars($settings['email_from']) ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <button type="button" class="btn btn-outline-primary" id="testEmail">
                                <i class="bi bi-envelope-check"></i> Test Email Configuration
                            </button>
                        </div>
                    </div>
                    
                    <!-- Payment Settings Tab -->
                    <div class="tab-pane fade" id="payment" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="currency" class="form-label">Currency</label>
                                    <select class="form-select" id="currency" name="currency" required>
                                        <option value="INR" <?= $settings['currency'] == 'INR' ? 'selected' : '' ?>>Indian Rupee (₹)</option>
                                        <option value="USD" <?= $settings['currency'] == 'USD' ? 'selected' : '' ?>>US Dollar ($)</option>
                                        <option value="EUR" <?= $settings['currency'] == 'EUR' ? 'selected' : '' ?>>Euro (€)</option>
                                        <option value="GBP" <?= $settings['currency'] == 'GBP' ? 'selected' : '' ?>>British Pound (£)</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="tax_rate" class="form-label">Tax Rate (%)</label>
                                    <input type="number" step="0.01" class="form-control" id="tax_rate" name="tax_rate" 
                                           value="<?= htmlspecialchars($settings['tax_rate']) ?>" required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="payment_methods" class="form-label">Enabled Payment Methods</label>
                                    <select class="form-select" id="payment_methods" name="payment_methods[]" multiple>
                                        <option value="cod" <?= strpos($settings['payment_methods'], 'cod') !== false ? 'selected' : '' ?>>Cash on Delivery</option>
                                        <option value="paypal" <?= strpos($settings['payment_methods'], 'paypal') !== false ? 'selected' : '' ?>>PayPal</option>
                                        <option value="stripe" <?= strpos($settings['payment_methods'], 'stripe') !== false ? 'selected' : '' ?>>Stripe</option>
                                        <option value="razorpay" <?= strpos($settings['payment_methods'], 'razorpay') !== false ? 'selected' : '' ?>>Razorpay</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="stripe_pk" class="form-label">Stripe Publishable Key</label>
                                    <input type="text" class="form-control" id="stripe_pk" name="stripe_pk" 
                                           value="<?= htmlspecialchars($settings['stripe_pk']) ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="stripe_sk" class="form-label">Stripe Secret Key</label>
                                    <input type="password" class="form-control" id="stripe_sk" name="stripe_sk" 
                                           value="<?= htmlspecialchars($settings['stripe_sk']) ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- SEO Settings Tab -->
                    <div class="tab-pane fade" id="seo" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="meta_title" class="form-label">Meta Title</label>
                                    <input type="text" class="form-control" id="meta_title" name="meta_title" 
                                           value="<?= htmlspecialchars($settings['meta_title']) ?>">
                                    <div class="form-text">Typically 50-60 characters</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="meta_description" class="form-label">Meta Description</label>
                                    <textarea class="form-control" id="meta_description" name="meta_description" rows="3"><?= htmlspecialchars($settings['meta_description']) ?></textarea>
                                    <div class="form-text">Typically 150-160 characters</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="meta_keywords" class="form-label">Meta Keywords</label>
                                    <textarea class="form-control" id="meta_keywords" name="meta_keywords" rows="3"><?= htmlspecialchars($settings['meta_keywords']) ?></textarea>
                                    <div class="form-text">Comma separated keywords</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="google_analytics" class="form-label">Google Analytics ID</label>
                                    <input type="text" class="form-control" id="google_analytics" name="google_analytics" 
                                           value="<?= htmlspecialchars($settings['google_analytics']) ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="facebook_pixel" class="form-label">Facebook Pixel ID</label>
                                    <input type="text" class="form-control" id="facebook_pixel" name="facebook_pixel" 
                                           value="<?= htmlspecialchars($settings['facebook_pixel']) ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Maintenance Settings Tab -->
                    <div class="tab-pane fade" id="maintenance" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3 form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" 
                                           <?= $settings['maintenance_mode'] == '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="maintenance_mode">Enable Maintenance Mode</label>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="maintenance_message" class="form-label">Maintenance Message</label>
                                    <textarea class="form-control" id="maintenance_message" name="maintenance_message" rows="5"><?= htmlspecialchars($settings['maintenance_message']) ?></textarea>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h5 class="card-title">Maintenance Mode</h5>
                                        <p class="card-text">
                                            When enabled, only administrators can access the site. All other visitors will see 
                                            the maintenance message.
                                        </p>
                                        <div class="alert alert-warning">
                                            <i class="bi bi-exclamation-triangle"></i> Remember to disable maintenance mode 
                                            when you're done working on the site.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-end mt-4">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="bi bi-save"></i> Save Settings
                    </button>
                </div>
            </form>
        </main>
    </div>
</div>

<script>
// Test email configuration
document.getElementById('testEmail').addEventListener('click', function() {
    alert('This would send a test email in a real implementation');
});

// Initialize select2 for multiple select
document.addEventListener('DOMContentLoaded', function() {
    // This would initialize select2 if included
    // $('#payment_methods').select2();
});
</script>

<?php include 'footer.php'; ?>