<?php
require_once '../config.php';
require_once '../auth.php';

requireAdmin();

// Get stats with improved queries (prepared statements)
$stats = [];
$stats['users'] = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_active=1")->fetch_assoc()['count'];
$stats['inactive_users'] = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_active=0")->fetch_assoc()['count'];
$stats['products'] = $conn->query("SELECT COUNT(*) as count FROM products WHERE is_active=1")->fetch_assoc()['count'];
$stats['orders'] = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
$stats['pending_orders'] = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status='pending'")->fetch_assoc()['count'];
$stats['categories'] = $conn->query("SELECT COUNT(*) as count FROM categories WHERE is_active=1")->fetch_assoc()['count'];
$stats['revenue'] = $conn->query("SELECT SUM(total) as total FROM orders WHERE status='delivered'")->fetch_assoc()['total'] ?? 0;
$stats['monthly_revenue'] = $conn->query("SELECT SUM(total) as total FROM orders WHERE status='delivered' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)")->fetch_assoc()['total'] ?? 0;

// Recent orders with pagination and filtering capability
$recent_orders = $conn->query("
    SELECT o.id, o.order_number, u.name as customer, o.total, o.status, o.created_at 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC 
    LIMIT 5
");

// Low stock products with severity indicator
$low_stock = $conn->query("
    SELECT id, name, stock, price, (SELECT name FROM categories WHERE id=products.category_id) as category 
    FROM products 
    WHERE stock < 10 AND is_active=1 
    ORDER BY stock ASC 
    LIMIT 5
");

// Sales chart data (last 30 days) with daily breakdown
$sales_data = [];
$result = $conn->query("
    SELECT DATE(created_at) as date, SUM(total) as daily_sales, COUNT(*) as order_count
    FROM orders 
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
    GROUP BY DATE(created_at)
");
while ($row = $result->fetch_assoc()) {
    $sales_data[] = $row;
}

// Order status distribution for pie chart
$status_distribution = [];
$result = $conn->query("
    SELECT status, COUNT(*) as count 
    FROM orders 
    GROUP BY status
");
while ($row = $result->fetch_assoc()) {
    $status_distribution[$row['status']] = $row['count'];
}

// Recent activity log
$recent_activity = $conn->query("
    SELECT * FROM activity_log 
    ORDER BY created_at DESC 
    LIMIT 5
");

// Top selling products
$top_products = $conn->query("
    SELECT p.id, p.name, p.price, SUM(oi.quantity) as total_sold, p.stock
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = 'delivered'
    GROUP BY p.id
    ORDER BY total_sold DESC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?= htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css">
    <style>
        :root {
            --primary: #4e73df;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --secondary: #858796;
            --dark: #5a5c69;
        }
        
        body {
            font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background-color: #f8f9fc;
        }       
        
        .stat-card {
            transition: transform 0.3s, box-shadow 0.3s;
            border-left: 0.25rem solid;
            border-radius: 0.35rem;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        
        .stat-card.primary { border-left-color: var(--primary); }
        .stat-card.success { border-left-color: var(--success); }
        .stat-card.info { border-left-color: var(--info); }
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.danger { border-left-color: var(--danger); }
        .stat-card.secondary { border-left-color: var(--secondary); }
        
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .progress {
            height: 1rem;
            border-radius: 0.35rem;
        }
        
        .progress-bar {
            font-size: 0.65rem;
            font-weight: 700;
        }
        
        .badge {
            font-weight: 600;
            padding: 0.35em 0.65em;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .chart-area, .chart-pie {
            position: relative;
            height: 20rem;
            width: 100%;
        }
        
        @media (min-width: 768px) {
            .chart-area {
                height: 20rem;
            }
            .chart-pie {
                height: 15rem;
            }
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        
        /* Animation classes */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Custom tooltip */
        .custom-tooltip {
            position: relative;
            display: inline-block;
        }
        
        .custom-tooltip .tooltip-text {
            visibility: hidden;
            width: 200px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            transform: translateX(-50%);
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .custom-tooltip:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php include 'element/sidebar.php'; ?>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard Overview</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="exportDashboard">
                                <i class="bi bi-download"></i> Export
                            </button>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="timeRangeDropdown" data-bs-toggle="dropdown">
                                    <i class="bi bi-calendar"></i> Last 30 Days
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" data-range="7">Last 7 Days</a></li>
                                    <li><a class="dropdown-item" href="#" data-range="30">Last 30 Days</a></li>
                                    <li><a class="dropdown-item" href="#" data-range="90">Last 90 Days</a></li>
                                    <li><a class="dropdown-item" href="#" data-range="365">Last Year</a></li>
                                </ul>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-primary" id="refreshDashboard">
                            <i class="bi bi-arrow-clockwise"></i> Refresh
                        </button>
                    </div>
                </div>
                
                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card primary h-100 animate__animated animate__fadeIn">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                            Total Users</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?= htmlspecialchars($stats['users']) ?></div>
                                        <div class="mt-2 text-xs">
                                            <span class="text-success fw-bold">
                                                <i class="bi bi-arrow-up"></i> 12%
                                            </span> Since last month
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-people-fill fs-1 text-primary"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="users.php" class="text-xs text-primary">View Details <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card success h-100 animate__animated animate__fadeIn animate__delay-1s">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-success text-uppercase mb-1">
                                            Active Products</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?= htmlspecialchars($stats['products']) ?></div>
                                        <div class="mt-2 text-xs">
                                            <span class="text-danger fw-bold">
                                                <i class="bi bi-arrow-down"></i> 3%
                                            </span> Since last month
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-box-seam fs-1 text-success"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="products.php" class="text-xs text-success">View Details <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card info h-100 animate__animated animate__fadeIn animate__delay-2s">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-info text-uppercase mb-1">
                                            Total Orders</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?= htmlspecialchars($stats['orders']) ?></div>
                                        <div class="mt-2 text-xs">
                                            <span class="text-success fw-bold">
                                                <i class="bi bi-arrow-up"></i> 24%
                                            </span> Since last month
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-cart-check fs-1 text-info"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="orders.php" class="text-xs text-info">View Details <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card warning h-100 animate__animated animate__fadeIn animate__delay-3s">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-warning text-uppercase mb-1">
                                            Pending Orders</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?= htmlspecialchars($stats['pending_orders']) ?></div>
                                        <div class="mt-2 text-xs">
                                            <span class="text-success fw-bold">
                                                <i class="bi bi-arrow-down"></i> 8%
                                            </span> Since last month
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-hourglass-split fs-1 text-warning"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="orders.php?status=pending" class="text-xs text-warning">View Details <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card danger h-100 animate__animated animate__fadeIn animate__delay-4s">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-danger text-uppercase mb-1">
                                            Monthly Revenue</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800">₹<?= number_format($stats['monthly_revenue'], 2) ?></div>
                                        <div class="mt-2 text-xs">
                                            <span class="text-success fw-bold">
                                                <i class="bi bi-arrow-up"></i> 18%
                                            </span> Since last month
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-currency-rupee fs-1 text-danger"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="reports.php" class="text-xs text-danger">View Details <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card secondary h-100 animate__animated animate__fadeIn animate__delay-5s">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs fw-bold text-secondary text-uppercase mb-1">
                                            Low Stock Items</div>
                                        <div class="h5 mb-0 fw-bold text-gray-800"><?= $low_stock->num_rows ?></div>
                                        <div class="mt-2 text-xs">
                                            <span class="text-danger fw-bold">
                                                <i class="bi bi-arrow-up"></i> 5%
                                            </span> Since last month
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-exclamation-triangle fs-1 text-secondary"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="products.php?filter=low_stock" class="text-xs text-secondary">View Details <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div class="row mb-4">
                    <div class="col-lg-8">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 fw-bold text-primary">Sales Overview (Last 30 Days)</h6>
                                <div class="dropdown no-arrow">
                                    <a class="dropdown-toggle" href="#" role="button" id="salesChartMenu" 
                                       data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="bi bi-three-dots-vertical text-gray-400"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end shadow">
                                        <a class="dropdown-item" href="#" data-range="7">Last 7 Days</a>
                                        <a class="dropdown-item" href="#" data-range="30">Last 30 Days</a>
                                        <a class="dropdown-item" href="#" data-range="90">Last 90 Days</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="reports.php">View Full Report</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="chart-area">
                                    <canvas id="salesChart"></canvas>
                                </div>
                                <div class="mt-4 text-center small">
                                    <span class="mr-2">
                                        <i class="bi bi-circle-fill text-primary"></i> Sales
                                    </span>
                                    <span class="mr-2">
                                        <i class="bi bi-circle-fill text-gray-300"></i> Previous Period
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 fw-bold text-primary">Order Status Distribution</h6>
                            </div>
                            <div class="card-body">
                                <div class="chart-pie pt-4 pb-2">
                                    <canvas id="orderStatusChart"></canvas>
                                </div>
                                <div class="mt-4 text-center small">
                                    <span class="mr-2">
                                        <i class="bi bi-circle-fill text-primary"></i> Pending
                                    </span>
                                    <span class="mr-2">
                                        <i class="bi bi-circle-fill text-success"></i> Delivered
                                    </span>
                                    <span class="mr-2">
                                        <i class="bi bi-circle-fill text-info"></i> Processing
                                    </span>
                                    <span class="mr-2">
                                        <i class="bi bi-circle-fill text-danger"></i> Cancelled
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity and Top Products -->
                <div class="row mb-4">
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold text-primary">Recent Activity</h6>
                                <a href="activity_log.php" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="list-group list-group-flush">
                                    <?php while ($activity = $recent_activity->fetch_assoc()): ?>
                                    <div class="list-group-item list-group-item-action">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h6 class="mb-1"><?= htmlspecialchars($activity['action']) ?></h6>
                                            <small class="text-muted"><?= time_elapsed_string($activity['created_at']) ?></small>
                                        </div>
                                        <p class="mb-1"><?= htmlspecialchars($activity['details']) ?></p>
                                        <small class="text-muted">By <?= htmlspecialchars($activity['user_id']) ?></small>
                                    </div>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold text-primary">Top Selling Products</h6>
                                <a href="reports.php?report=top_products" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th>Sold</th>
                                                <th>Stock</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
    <?php while ($product = $top_products->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($product['name']) ?></td>
        <td>₹<?= number_format($product['price'], 2) ?></td>
        <td><?= htmlspecialchars($product['total_sold']) ?></td>
        <td>
            <div class="progress">
                <?php
                // Calculate the percentage first
                $denominator = $product['total_sold'] + $product['stock'];
                $percentage = $denominator > 0 
                    ? min(100, ($product['stock'] / $denominator) * 100)
                    : 0;
                ?>
                <div class="progress-bar bg-<?= ($product['stock'] < 10) ? 'warning' : 'success' ?>" 
                     role="progressbar" style="width: <?= $percentage ?>%">
                    <?= $product['stock'] ?>
                </div>
            </div>
        </td>
        <td>
            <a href="product_edit.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-primary">
                <i class="bi bi-pencil-fill"></i> Edit
            </a>
        </td>
    </tr>
    <?php endwhile; ?>
</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Orders -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 fw-bold text-primary">Recent Orders</h6>
                        <div>
                            <div class="btn-group me-2">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" 
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-filter"></i> Filter
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="?status=all">All Orders</a></li>
                                    <li><a class="dropdown-item" href="?status=pending">Pending</a></li>
                                    <li><a class="dropdown-item" href="?status=processing">Processing</a></li>
                                    <li><a class="dropdown-item" href="?status=delivered">Delivered</a></li>
                                    <li><a class="dropdown-item" href="?status=cancelled">Cancelled</a></li>
                                </ul>
                            </div>
                            <a href="orders.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Customer</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($order = $recent_orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($order['order_number']) ?></td>
                                        <td><?= htmlspecialchars($order['customer']) ?></td>
                                        <td><?= date('M d, Y', strtotime($order['created_at'])) ?></td>
                                        <td>₹<?= number_format($order['total'], 2) ?></td>
                                        <td>
                                            <span class="badge bg-<?= 
                                                $order['status'] == 'delivered' ? 'success' : 
                                                ($order['status'] == 'cancelled' ? 'danger' : 
                                                ($order['status'] == 'processing' ? 'info' : 'warning')) 
                                            ?>">
                                                <?= ucfirst($order['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="order_details.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-eye-fill"></i>
                                                </a>
                                                <a href="order_edit.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-outline-secondary">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Low Stock Products -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 fw-bold text-primary">Low Stock Products</h6>
                        <a href="products.php?filter=low_stock" class="btn btn-sm btn-warning">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Product ID</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($product = $low_stock->fetch_assoc()): ?>
                                    <tr class="<?= $product['stock'] < 3 ? 'table-danger' : ($product['stock'] < 5 ? 'table-warning' : '') ?>">
                                        <td><?= htmlspecialchars($product['id']) ?></td>
                                        <td><?= htmlspecialchars($product['name']) ?></td>
                                        <td><?= htmlspecialchars($product['category']) ?></td>
                                        <td>₹<?= number_format($product['price'], 2) ?></td>
                                        <td>
                                            <div class="progress">
                                                <div class="progress-bar bg-<?= $product['stock'] < 3 ? 'danger' : ($product['stock'] < 5 ? 'warning' : 'info') ?>" 
                                                     role="progressbar" style="width: <?= min(100, ($product['stock'] / 10) * 100) ?>%">
                                                    <?= $product['stock'] ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="product_edit.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-pencil-fill"></i> Update
                                                </a>
                                                <button class="btn btn-sm btn-outline-secondary custom-tooltip" 
                                                        data-product-id="<?= $product['id'] ?>">
                                                    <i class="bi bi-lightning-charge-fill"></i> Reorder
                                                    <span class="tooltip-text">Quick reorder for this product</span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Quick Actions Modal -->
    <div class="modal fade" id="quickActionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Quick Action</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="quickActionContent">
                    <!-- Content will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="executeQuickAction">Execute</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/luxon@2.3.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-luxon@1.1.0"></script>
    <script>
        // Sales Chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($sales_data, 'date')) ?>,
                datasets: [{
                    label: 'Daily Sales',
                    data: <?= json_encode(array_column($sales_data, 'daily_sales')) ?>,
                    backgroundColor: 'rgba(78, 115, 223, 0.05)',
                    borderColor: 'rgba(78, 115, 223, 1)',
                    pointBackgroundColor: 'rgba(78, 115, 223, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(78, 115, 223, 1)',
                    tension: 0.3,
                    fill: true
                }, {
                    label: 'Previous Period',
                    data: <?= json_encode(array_map(function($val) { return $val * 0.85; }, array_column($sales_data, 'daily_sales'))) ?>,
                    borderColor: 'rgba(200, 200, 200, 1)',
                    pointBackgroundColor: 'rgba(200, 200, 200, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(200, 200, 200, 1)',
                    borderDash: [5, 5],
                    tension: 0.3
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += '₹' + context.parsed.y.toLocaleString('en-IN');
                                }
                                return label;
                            }
                        }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString('en-IN');
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)',
                            drawBorder: false
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                            drawBorder: false
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
        
        // Order Status Chart
        const statusCtx = document.getElementById('orderStatusChart').getContext('2d');
        const statusChart = new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'Processing', 'Delivered', 'Cancelled'],
                datasets: [{
                    data: [
                        <?= $status_distribution['pending'] ?? 0 ?>,
                        <?= $status_distribution['processing'] ?? 0 ?>,
                        <?= $status_distribution['delivered'] ?? 0 ?>,
                        <?= $status_distribution['cancelled'] ?? 0 ?>
                    ],
                    backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#e74a3b'],
                    hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf', '#d62c1a'],
                    hoverBorderColor: "rgba(234, 236, 244, 1)",
                }],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    },
                    legend: {
                        display: false
                    }
                },
                cutout: '70%',
            },
        });

        // Time range filter
        document.querySelectorAll('[data-range]').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const range = this.getAttribute('data-range');
                // In a real app, this would reload the data via AJAX
                document.getElementById('timeRangeDropdown').textContent = 
                    `Last ${range} Day${range == 1 ? '' : 's'}`;
                // Show loading animation
                const refreshBtn = document.getElementById('refreshDashboard');
                const originalHtml = refreshBtn.innerHTML;
                refreshBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Loading...';
                
                // Simulate data loading
                setTimeout(() => {
                    refreshBtn.innerHTML = originalHtml;
                    // Here you would update the charts with new data via AJAX
                    alert(`Time range changed to last ${range} days. In a real app, this would update the data.`);
                }, 1000);
            });
        });

        // Refresh dashboard
        document.getElementById('refreshDashboard').addEventListener('click', function() {
            const originalHtml = this.innerHTML;
            this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Loading...';
            
            // Simulate refresh
            setTimeout(() => {
                this.innerHTML = originalHtml;
                // In a real app, this would reload the data via AJAX
                location.reload();
            }, 1000);
        });

        // Export dashboard
        document.getElementById('exportDashboard').addEventListener('click', function() {
            // In a real app, this would generate a PDF or Excel report
            alert('Export functionality would generate a report here.');
        });

        // Quick reorder buttons
        document.querySelectorAll('.custom-tooltip').forEach(item => {
            item.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                // In a real app, this would open a modal with reorder options
                alert(`Quick reorder for product ID: ${productId}`);
            });
        });

        // Tooltip initialization
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>