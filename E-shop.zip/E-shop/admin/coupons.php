<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
requireAdmin();

// Handle bulk actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_coupons'])) {
        $action = $_POST['bulk_action'];
        $ids = implode(",", array_map('intval', $_POST['selected_coupons']));
        
        if ($action == 'delete') {
            $conn->query("DELETE FROM coupons WHERE id IN ($ids)");
            $_SESSION['message'] = count($_POST['selected_coupons']) . ' coupons deleted';
        } elseif ($action == 'activate') {
            $conn->query("UPDATE coupons SET is_active = 1 WHERE id IN ($ids)");
            $_SESSION['message'] = count($_POST['selected_coupons']) . ' coupons activated';
        } elseif ($action == 'deactivate') {
            $conn->query("UPDATE coupons SET is_active = 0 WHERE id IN ($ids)");
            $_SESSION['message'] = count($_POST['selected_coupons']) . ' coupons deactivated';
        }
    } else {
        $_SESSION['error'] = 'No coupons selected';
    }
    header("Location: coupons.php");
    exit();
}

// Handle single delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM coupons WHERE id = $id");
    $_SESSION['message'] = 'Coupon deleted successfully';
    header("Location: coupons.php");
    exit();
}

// Filtering
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$where = '';
if ($filter == 'active') {
    $where = "WHERE is_active = 1 AND valid_to >= CURDATE()";
} elseif ($filter == 'expired') {
    $where = "WHERE valid_to < CURDATE()";
} elseif ($filter == 'inactive') {
    $where = "WHERE is_active = 0";
}

// Get coupons with usage count
$coupons = $conn->query("
    SELECT c.*, COUNT(o.id) as usage_count
    FROM coupons c
    LEFT JOIN orders o ON o.coupon_code = c.code
    $where
    GROUP BY c.id
    ORDER BY valid_to DESC
");


?>

<div class="container-fluid">
    <div class="row">
        <?php include 'element/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Coupon Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="coupon_add.php" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Add Coupon
                        </a>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-filter"></i> Filter: <?= ucfirst($filter) ?>
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?filter=all">All Coupons</a></li>
                            <li><a class="dropdown-item" href="?filter=active">Active</a></li>
                            <li><a class="dropdown-item" href="?filter=expired">Expired</a></li>
                            <li><a class="dropdown-item" href="?filter=inactive">Inactive</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <?php include 'element/messages.php'; ?>
            
            <form method="post" id="bulkActionForm">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="input-group">
                            <select name="bulk_action" class="form-select" required>
                                <option value="">Bulk Actions</option>
                                <option value="activate">Activate</option>
                                <option value="deactivate">Deactivate</option>
                                <option value="delete">Delete</option>
                            </select>
                            <button type="submit" class="btn btn-outline-primary">Apply</button>
                        </div>
                    </div>
                    <div class="col-md-8 text-end">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="selectAll">
                            <label class="form-check-label" for="selectAll">Select All</label>
                        </div>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="40px"></th>
                                <th>Code</th>
                                <th>Discount</th>
                                <th>Valid From</th>
                                <th>Valid To</th>
                                <th>Min Order</th>
                                <th>Usage</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($coupons->num_rows > 0): ?>
                                <?php while ($coupon = $coupons->fetch_assoc()): ?>
                                <tr class="<?= strtotime($coupon['valid_to']) < time() ? 'table-warning' : '' ?>">
                                    <td><input type="checkbox" name="selected_coupons[]" value="<?= $coupon['id'] ?>" class="form-check-input"></td>
                                    <td>
                                        <span class="badge bg-light text-dark"><?= $coupon['code'] ?></span>
                                    </td>
                                    <td>
                                        <?= $coupon['discount_type'] == 'percentage' ? 
                                            $coupon['discount_value'] . '%' : 
                                            '₹' . $coupon['discount_value'] 
                                        ?>
                                    </td>
                                    <td><?= date('M d, Y', strtotime($coupon['valid_from'])) ?></td>
                                    <td><?= date('M d, Y', strtotime($coupon['valid_to'])) ?></td>
                                    <td><?= $coupon['min_order_value'] ? '₹' . $coupon['min_order_value'] : 'None' ?></td>
                                    <td><?= $coupon['usage_count'] ?> times</td>
                                    <td>
                                        <?php if (strtotime($coupon['valid_to']) < time()): ?>
                                            <span class="badge bg-secondary">Expired</span>
                                        <?php else: ?>
                                            <span class="badge bg-<?= $coupon['is_active'] ? 'success' : 'danger' ?>">
                                                <?= $coupon['is_active'] ? 'Active' : 'Inactive' ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="coupon_edit.php?id=<?= $coupon['id'] ?>" class="btn btn-primary">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="coupons.php?delete=<?= $coupon['id'] ?>" class="btn btn-danger" 
                                               onclick="return confirm('Are you sure you want to delete this coupon?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5">
                                        <div class="text-muted">No coupons found</div>
                                        <a href="coupon_add.php" class="btn btn-primary mt-3">
                                            <i class="bi bi-plus-circle"></i> Add First Coupon
                                        </a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </main>
    </div>
</div>

<script>
// Select all functionality
document.getElementById('selectAll').addEventListener('change', function() {
    document.querySelectorAll('input[name="selected_coupons[]"]').forEach(el => {
        el.checked = this.checked;
    });
});

// Bulk form validation
document.getElementById('bulkActionForm').addEventListener('submit', function(e) {
    const selected = document.querySelectorAll('input[name="selected_coupons[]"]:checked').length;
    const action = document.querySelector('select[name="bulk_action"]').value;
    
    if (selected === 0) {
        e.preventDefault();
        alert('Please select at least one coupon');
        return false;
    }
    
    if (!action) {
        e.preventDefault();
        alert('Please select a bulk action');
        return false;
    }
    
    if (action === 'delete' && !confirm(`Are you sure you want to delete ${selected} coupon(s)?`)) {
        e.preventDefault();
        return false;
    }
});
</script>

<?php include 'footer.php'; ?>