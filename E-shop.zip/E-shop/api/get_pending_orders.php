<?php
require_once '../config.php';
require_once '../auth.php';

// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

try {
    // Verify authentication
    $auth = new Auth();
    if (!$auth->verifyToken()) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized access']);
        exit;
    }

    // Verify admin privileges
    if (!$auth->isAdmin()) {
        http_response_code(403);
        echo json_encode(['error' => 'Admin access required']);
        exit;
    }

    // Prepare and execute query to count pending orders
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE status='pending'");
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch the count
    $data = $result->fetch_assoc();
    
    // Return the count as JSON
    echo json_encode([
        'success' => true,
        'count' => (int)$data['count'],
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    // Handle errors
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}

// Close connection
if (isset($conn)) {
    $conn->close();
}
?>