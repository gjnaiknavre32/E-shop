<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <?php include 'element/nav.php'; ?>
    
    <div class="container py-5">
        <div class="row">
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Filter Products</h5>
                    </div>
                    <div class="card-body">
                        <form method="get" action="products.php">
                            <div class="form-group">
                                <label>Category</label>
                                <select name="category" class="form-control">
                                    <option value="">All Categories</option>
                                    <?php
                                    $sql = "SELECT * FROM categories";
                                    $result = $conn->query($sql);
                                    while ($row = $result->fetch_assoc()) {
                                        $selected = (isset($_GET['category']) && $_GET['category'] == $row['id']) ? 'selected' : '';
                                        echo '<option value="'.$row['id'].'" '.$selected.'>'.$row['name'].'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Price Range</label>
                                <select name="price" class="form-control">
                                    <option value="">All Prices</option>
                                    <option value="0-500" <?php echo (isset($_GET['price']) && $_GET['price'] == '0-500') ? 'selected' : ''; ?>>Under ₹500</option>
                                    <option value="500-1000" <?php echo (isset($_GET['price']) && $_GET['price'] == '500-1000') ? 'selected' : ''; ?>>₹500 - ₹1000</option>
                                    <option value="1000-5000" <?php echo (isset($_GET['price']) && $_GET['price'] == '1000-5000') ? 'selected' : ''; ?>>₹1000 - ₹5000</option>
                                    <option value="5000-10000" <?php echo (isset($_GET['price']) && $_GET['price'] == '5000-10000') ? 'selected' : ''; ?>>₹5000 - ₹10000</option>
                                    <option value="10000" <?php echo (isset($_GET['price']) && $_GET['price'] == '10000') ? 'selected' : ''; ?>>Above ₹10000</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Sort By</label>
                                <select name="sort" class="form-control">
                                    <option value="newest" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'newest') ? 'selected' : ''; ?>>Newest First</option>
                                    <option value="price_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') ? 'selected' : ''; ?>>Price: Low to High</option>
                                    <option value="price_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') ? 'selected' : ''; ?>>Price: High to Low</option>
                                    <option value="name_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'name_asc') ? 'selected' : ''; ?>>Name: A to Z</option>
                                    <option value="name_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'name_desc') ? 'selected' : ''; ?>>Name: Z to A</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Apply Filters</button>
                            <a href="products.php" class="btn btn-secondary btn-block mt-2">Reset Filters</a>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <h1 class="mb-4">All Products</h1>
                
                <div class="row">
                    <?php
                    // Build SQL query based on filters
                    $sql = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE 1";
                    
                    // Category filter
                    if (isset($_GET['category']) && !empty($_GET['category'])) {
                        $category_id = $conn->real_escape_string($_GET['category']);
                        $sql .= " AND p.category_id = '$category_id'";
                    }
                    
                    // Price filter
                    if (isset($_GET['price']) && !empty($_GET['price'])) {
                        $price_range = explode('-', $_GET['price']);
                        if (count($price_range) == 2) {
                            $sql .= " AND p.price BETWEEN {$price_range[0]} AND {$price_range[1]}";
                        } elseif ($_GET['price'] == '10000') {
                            $sql .= " AND p.price > 10000";
                        }
                    }
                    
                    // Sorting
                    $sort_options = [
                        'newest' => 'p.created_at DESC',
                        'price_asc' => 'p.price ASC',
                        'price_desc' => 'p.price DESC',
                        'name_asc' => 'p.name ASC',
                        'name_desc' => 'p.name DESC'
                    ];
                    $sort = isset($_GET['sort']) && array_key_exists($_GET['sort'], $sort_options) ? $_GET['sort'] : 'newest';
                    $sql .= " ORDER BY " . $sort_options[$sort];
                    
                    // Pagination
                    $per_page = 12;
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $offset = ($page - 1) * $per_page;
                    $total_result = $conn->query($sql)->num_rows;
                    $total_pages = ceil($total_result / $per_page);
                    
                    $sql .= " LIMIT $offset, $per_page";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<div class="col-md-4 mb-4">
                                <div class="card product-card h-100">
                                    <img src="product_pic/'.$row['image'].'" class="card-img-top" alt="'.$row['name'].'">
                                    <div class="card-body">
                                        <h5 class="card-title">'.$row['name'].'</h5>
                                        <p class="text-muted">'.$row['category_name'].'</p>
                                        <p class="card-text">₹'.$row['price'].'</p>
                                        <a href="product_details.php?id='.$row['id'].'" class="btn btn-primary">View Details</a>
                                    </div>
                                </div>
                            </div>';
                        }
                    } else {
                        echo '<div class="col-12"><div class="alert alert-info">No products found matching your criteria.</div></div>';
                    }
                    ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center mt-4">
                        <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">Previous</a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
                        </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Next</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include 'element/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>