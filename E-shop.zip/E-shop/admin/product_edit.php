<?php
require_once '../config.php';
require_once '../auth.php';

requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int)$_GET['id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $description = $conn->real_escape_string($_POST['description']);
    $price = (float)$_POST['price'];
    $brand = $conn->real_escape_string($_POST['brand']);
    $weight = $conn->real_escape_string($_POST['weight']);
    $dimensions = $conn->real_escape_string($_POST['dimensions']);
    $stock = (int)$_POST['stock'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    // Handle image upload
    $image = $_POST['current_image'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../product_pic/';
        $file_ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image = uniqid() . '.' . $file_ext;
        move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $image);
        
        // Delete old image if it exists
        if (!empty($_POST['current_image'])) {
            @unlink($upload_dir . $_POST['current_image']);
        }
    }
    
    $sql = "UPDATE products SET 
            category_id = ?, 
            name = ?, 
            description = ?, 
            price = ?, 
            image = ?, 
            brand = ?, 
            weight = ?, 
            dimensions = ?, 
            stock = ?, 
            featured = ? 
            WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issdssssiii", $category_id, $name, $description, $price, $image, $brand, $weight, $dimensions, $stock, $featured, $product_id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = 'Product updated successfully';
        header("Location: products.php");
        exit();
    } else {
        $_SESSION['error'] = 'Error updating product';
    }
}

// Get product details
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: products.php");
    exit();
}

// Get all categories
$categories = $conn->query("SELECT * FROM categories ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Admin - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
    <?php include '../element/nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'element/sidebar.php'; ?>
            
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Product</h1>
                    <a href="products.php" class="btn btn-secondary">Back to Products</a>
                </div>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>
                
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="current_image" value="<?php echo $product['image']; ?>">
                    
                    <div class="form-group">
                        <label>Product Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo $product['name']; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category_id" class="form-control">
                            <option value="">Select Category</option>
                            <?php while ($cat = $categories->fetch_assoc()): ?>
                            <option value="<?php echo $cat['id']; ?>" <?php echo $cat['id'] == $product['category_id'] ? 'selected' : ''; ?>>
                                <?php echo $cat['name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo $product['description']; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Price (₹)</label>
                        <input type="number" name="price" class="form-control" step="0.01" min="0" value="<?php echo $product['price']; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Current Image</label><br>
                        <img src="../product_pic/<?php echo $product['image']; ?>" width="100" class="mb-2">
                        <input type="file" name="image" class="form-control-file">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Brand</label>
                            <input type="text" name="brand" class="form-control" value="<?php echo $product['brand']; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Weight</label>
                            <input type="text" name="weight" class="form-control" value="<?php echo $product['weight']; ?>" placeholder="e.g. 500g, 1kg">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Dimensions</label>
                            <input type="text" name="dimensions" class="form-control" value="<?php echo $product['dimensions']; ?>" placeholder="e.g. 10x10x5 cm">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Stock Quantity</label>
                            <input type="number" name="stock" class="form-control" min="0" value="<?php echo $product['stock']; ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="featured" id="featured" <?php echo $product['featured'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="featured">
                                    Featured Product
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Update Product</button>
                </form>
            </main>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>